/**
 * ***************************************************************************** Copyright (c) 2007
 * IBM Corporation. All rights reserved. This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 *
 * <p>Contributors: IBM Corporation - initial API and implementation
 * *****************************************************************************
 */
package com.ibm.wala.util.constant;

public class Selectors {
  public static final String selStart = "start()V";
  public static final String selExecutorExecute = "execute(Ljava/lang/Runnable;)V";
  public static final String selHandlerPost = "post(Ljava/lang/Runnable;)Z";
  public static final String selHandlerPostAtFrontOfQueue =
      "postAtFrontOfQueue(Ljava/lang/Runnable;)Z";
  public static final String selHandlerPostAtTime = "postAtTime(Ljava/lang/Runnable;J)Z";
  public static final String selHandlerPostAtTimeWithToken =
      "postAtTime(Ljava/lang/Runnable;Ljava/lang/Object;J)Z";
  public static final String selHandlerPostDelayed = "postDelayed(Ljava/lang/Runnable;J)Z";
  public static final String selHandlerSendEmptyMessage = "sendEmptyMessage(I)Z";
  public static final String selHandlerSendEmptyMessageAtTime = "sendEmptyMessageAtTime(IJ)Z";
  public static final String selHandlerSendEmptyMessageDelayed = "sendEmptyMessageDelayed(IJ)Z";
  public static final String selHandlerSendMessage = "postAtTime(Ljav;lang/Runnable;J)Z";
  public static final String selHandlerSendMessageAtFrontOfQueue =
      "sendMessageAtFrontOfQueue(Landroid/os/Message;)Z";
  public static final String selHandlerSendMessageAtTime =
      "sendMessageAtTime(Landroid/os/Message;J)Z";
  public static final String selHandlerSendMessageDelayed =
      "sendMessageDelayed(Landroid/os/Message;J)Z";
  public static final String selExecute = "execute([Ljava/lang/Object;)Landroid/os/AsyncTask;";
  public static final String selRun = "run()V";
  public static final String selHandlerHandleMessage = "handleMessage(Landroid/os/Message;)V";
  public static final String selDoInBackground =
      "doInBackground([Ljava/lang/Object;)Ljava/lang/Object;";

  // Timer
  public static final String selScheduleLong = "schedule(Ljava/util/TimerTask;J)V";
  public static final String selScheduleDate = "schedule(Ljava/util/TimerTask;Ljava/util/Date;)V";
  public static final String selScheduleDateLong =
      "schedule(Ljava/util/TimerTask;Ljava/util/Date;J)V";
  public static final String selScheduleLongLong = "schedule(Ljava/util/TimerTask;JJ)V";
  public static final String selScheduleAtFixedRateDate =
      "scheduleAtFixedRate(Ljava/util/TimerTask;Ljava/util/Date;J)V";
  public static final String selScheduleAtFixedRateLong =
      "scheduleAtFixedRate(Ljava/util/TimerTask;JJ)V";
}
