package com.ibm.wala.util.collections;

import com.ibm.wala.util.debug.Assertions;
import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

public class Triple<T, U, N> implements Serializable {

  private static final long serialVersionUID = 1861211857872739247L;
  public final T fst;
  public final U snd;
  public final N third;

  protected Triple(T fst, U snd, N third) {
    this.fst = fst;
    this.snd = snd;
    this.third = third;
  }

  private static boolean check(Object x, Object y) {
    return Objects.equals(x, y);
  }

  @SuppressWarnings("rawtypes")
  @Override
  public boolean equals(Object o) {
    return (o instanceof Triple)
        && check(fst, ((Triple) o).fst)
        && check(snd, ((Triple) o).snd)
        && check(third, ((Triple) o).third);
  }

  private static int hc(Object o) {
    return (o == null) ? 0 : o.hashCode();
  }

  @Override
  public int hashCode() {
    return hc(fst) * 7219 + hc(snd) * 7219 + hc(third);
  }

  public Iterator<Object> iterator() {
    return new Iterator<Object>() {
      byte nextFlag = 1;

      @Override
      public boolean hasNext() {
        return nextFlag > 0;
      }

      @Override
      public Object next() {
        switch (nextFlag) {
          case 1:
            nextFlag++;
            return fst;
          case 2:
            nextFlag++;
            return snd;
          case 3:
            nextFlag = 0;
            return third;
          default:
            throw new NoSuchElementException();
        }
      }

      @Override
      public void remove() {
        Assertions.UNREACHABLE();
      }
    };
  }

  @Override
  public String toString() {
    return "[" + fst + ',' + snd + ',' + third + ']';
  }

  public static <T, U, N> Triple<T, U, N> make(T x, U y, N z) {
    return new Triple<>(x, y, z);
  }
}
