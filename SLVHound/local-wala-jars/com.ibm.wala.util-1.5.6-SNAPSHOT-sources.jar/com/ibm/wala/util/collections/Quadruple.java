package com.ibm.wala.util.collections;

import com.ibm.wala.util.debug.Assertions;
import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

public class Quadruple<T, U, N, F> implements Serializable {

  private static final long serialVersionUID = 1861211857872739247L;
  public final T fst;
  public final U snd;
  public final N third;
  public final F fourth;

  protected Quadruple(T fst, U snd, N third, F fourth) {
    this.fst = fst;
    this.snd = snd;
    this.third = third;
    this.fourth = fourth;
  }

  private static boolean check(Object x, Object y) {
    return Objects.equals(x, y);
  }

  @SuppressWarnings("rawtypes")
  @Override
  public boolean equals(Object o) {
    return (o instanceof Quadruple)
        && check(fst, ((Quadruple) o).fst)
        && check(snd, ((Quadruple) o).snd)
        && check(third, ((Quadruple) o).third)
        && check(fourth, ((Quadruple) o).fourth);
  }

  private static int hc(Object o) {
    return (o == null) ? 0 : o.hashCode();
  }

  @Override
  public int hashCode() {
    return hc(fst) * 7219 + hc(snd) * 7219 + hc(third) * 7219 + hc(fourth);
  }

  public Iterator<Object> iterator() {
    return new Iterator<Object>() {
      byte nextFlag = 1;

      @Override
      public boolean hasNext() {
        return nextFlag > 0;
      }

      @Override
      public Object next() {
        switch (nextFlag) {
          case 1:
            nextFlag++;
            return fst;
          case 2:
            nextFlag++;
            return snd;
          case 3:
            nextFlag++;
            return third;
          case 4:
            nextFlag = 0;
            return fourth;
          default:
            throw new NoSuchElementException();
        }
      }

      @Override
      public void remove() {
        Assertions.UNREACHABLE();
      }
    };
  }

  @Override
  public String toString() {
    return "[" + fst + ',' + snd + ',' + third + ',' + fourth + ']';
  }

  public static <T, U, N, F> Quadruple<T, U, N, F> make(T x, U y, N z, F f) {
    return new Quadruple<>(x, y, z, f);
  }
}
