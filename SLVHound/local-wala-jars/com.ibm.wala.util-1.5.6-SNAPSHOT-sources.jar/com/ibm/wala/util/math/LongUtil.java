/*
 * Copyright (c) 2002 - 2006 IBM Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 */
package com.ibm.wala.util.math;

/** */
public class LongUtil {

  public static long pack(int hi, int lo) {
    return ((long) hi << 32) | lo;
  }

  public static int getHighInt(long v) {
    return (int) (v >> 32);
  }

  public static int getLowInt(long v) {
    return (int) (v & 0x000000ffffffffL);
  }
}
