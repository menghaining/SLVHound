/*
 * Copyright (c) 2007 IBM Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 */
package com.ibm.wala.ipa.cfg.exceptionpruning.interprocedural;

import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.cfg.exceptionpruning.ExceptionFilter;

public class IgnoreExceptionsInterFilter<Instruction>
    implements InterproceduralExceptionFilter<Instruction> {
  private final ExceptionFilter<Instruction> filter;

  public IgnoreExceptionsInterFilter(ExceptionFilter<Instruction> filter) {
    this.filter = filter;
  }

  @Override
  public ExceptionFilter<Instruction> getFilter(CGNode node) {
    return filter;
  }
}
