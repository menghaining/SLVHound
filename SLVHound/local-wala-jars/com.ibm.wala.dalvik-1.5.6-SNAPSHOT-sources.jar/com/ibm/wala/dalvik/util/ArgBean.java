package com.ibm.wala.dalvik.util;

import com.ibm.wala.types.FieldReference;
import com.ibm.wala.types.TypeReference;
import java.util.List;

public class ArgBean {
  // the index of base value in arguments of a invoke instruction
  private final int argIndex;
  // an accesspath exclude base value. eg: f.g.h
  private final List<FieldReference> mAccessPath;

  public ArgBean(int index, List<FieldReference> accesspath) {
    this.argIndex = index;
    this.mAccessPath = accesspath;
  }

  public int getIndex() {
    return argIndex;
  }

  public List<FieldReference> getAccessPath() {
    return mAccessPath;
  }

  public TypeReference getLastFieldType() {
    assert mAccessPath != null && mAccessPath.size() != 0;
    return mAccessPath.get(mAccessPath.size() - 1).getFieldType();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((mAccessPath == null) ? 0 : mAccessPath.hashCode());
    result = prime * result + argIndex;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    ArgBean other = (ArgBean) obj;
    if (mAccessPath == null) {
      if (other.mAccessPath != null) return false;
    } else if (!mAccessPath.equals(other.mAccessPath)) return false;
    if (argIndex != other.argIndex) return false;
    return true;
  }
}
