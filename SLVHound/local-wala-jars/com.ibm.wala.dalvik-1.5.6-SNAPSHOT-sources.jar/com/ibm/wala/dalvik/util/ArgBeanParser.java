package com.ibm.wala.dalvik.util;

import com.ibm.wala.dalvik.classLoader.DexIMethod;
import com.ibm.wala.dalvik.dex.instructions.GetField;
import com.ibm.wala.types.FieldReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jf.dexlib2.Opcode;

public class ArgBeanParser {
  List<ArgBean> argBeanList;

  public ArgBeanParser(List<ArgBean> argBeanList) {
    this.argBeanList = argBeanList;
  }

  public ArgBeanParserResult parseArgBean(DexIMethod dexMethod, int[] oldArgs) {
    ArgBeanParserResult result = new ArgBeanParserResult(oldArgs);
    // accesspath --> value
    Map<String, Integer> accessPath2Value = new HashMap<>();
    Map<String, String> accessPath2ValueType = new HashMap<>();
    for (ArgBean argBean : argBeanList) {
      int curIndex = argBean.getIndex();
      assert curIndex < oldArgs.length;
      String curAP = "" + curIndex;
      int curBase = oldArgs[curIndex];
      String curBaseType = "";
      accessPath2Value.put(curAP, curBase);
      for (FieldReference fReference : argBean.getAccessPath()) {
        curAP = curAP + fReference.getSignature();
        if (accessPath2Value.containsKey(curAP)) {
          curBase = accessPath2Value.get(curAP);
          curBaseType = accessPath2ValueType.get(curAP);
          continue;
        }
        int destination = dexMethod.increaseLocal();
        String clazzName = fReference.getDeclaringClass().getName().toString();
        if (clazzName.endsWith(";")) clazzName = clazzName.substring(0, clazzName.length() - 1);
        String fieldName = fReference.getName().toString();
        String fieldType = fReference.getFieldType().getName().toString();
        curBaseType = fieldType;
        if (fieldType.endsWith(";")) fieldType = fieldType.substring(0, fieldType.length() - 1);
        GetField getField =
            new GetField.GetInstanceField(
                dexMethod.getNextPC(),
                destination,
                curBase,
                clazzName,
                fieldName,
                fieldType,
                Opcode.IGET_OBJECT,
                dexMethod);
        result.addGetField(getField);
        accessPath2Value.put(curAP, destination);
        curBase = destination;
        accessPath2ValueType.put(curAP, curBaseType);
      }
      result.addArg(curBase);
      result.addArgType(curBaseType);
    }
    return result;
  }

  public class ArgBeanParserResult {
    private final List<GetField> getFieldList = new ArrayList<>();
    private final List<Integer> args = new ArrayList<>();
    private final List<String> argsType = new ArrayList<>();

    public ArgBeanParserResult(int[] oldArgs) {
      for (int i = 0; i < oldArgs.length; i++) {
        args.add(oldArgs[i]);
      }
    }

    public void addGetField(GetField getField) {
      getFieldList.add(getField);
    }

    public void addArg(int arg) {
      args.add(arg);
    }

    public void addArgType(String argType) {
      argsType.add(argType);
    }

    public List<GetField> getGetFieldList() {
      return getFieldList;
    }

    public List<Integer> getArgs() {
      return args;
    }

    public List<String> getArgsType() {
      return argsType;
    }
  }
}
