/*
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html.
 *
 * This file is a derivative of code released under the terms listed below.
 *
 */
/*
 * Copyright (c) 2009-2012,
 *
 * <p>Jonathan Bardin <astrosus@gmail.com> Steve Suh <suhsteve@gmail.com>
 *
 * <p>All rights reserved.
 *
 * <p>Redistribution and use in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met:
 *
 * <p>1. Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 *
 * <p>2. Redistributions in binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other materials provided with
 * the distribution.
 *
 * <p>3. The names of the contributors may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * <p>THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
 * WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.ibm.wala.dalvik.dex.util.config;

import com.ibm.wala.dalvik.classLoader.DexFileModule;
import com.ibm.wala.ipa.callgraph.AnalysisScope;
import com.ibm.wala.types.ClassLoaderReference;
import com.ibm.wala.util.config.AnalysisScopeReader;
import java.io.File;
import java.io.IOException;
import java.net.URI;

/**
 * Create AnalysisScope from java &amp; dalvik file.
 *
 * @see com.ibm.wala.ipa.callgraph.AnalysisScope
 */
public class DexAnalysisScopeReader extends AnalysisScopeReader {

  private static final ClassLoader WALA_CLASSLOADER = AnalysisScopeReader.class.getClassLoader();

  /* BEGIN Custom change: Fixes in AndroidAnalysisScope */
  // private static final String BASIC_FILE = "conf" + File.separator+ "primordial.txt";
  private static final String BASIC_FILE = "./primordial.txt"; // Path inside jar
  /* END Custom change: Fixes in AndroidAnalysisScope */
  public static AnalysisScope makeAndroidBinaryAnalysisScope(URI classPath, String exclusionsFile)
      throws IOException {
    if (classPath == null) {
      throw new IllegalArgumentException("classPath null");
    }
    AnalysisScope scope =
        AnalysisScopeReader.readJavaScope(BASIC_FILE, new File(exclusionsFile), WALA_CLASSLOADER);

    ClassLoaderReference loader = scope.getLoader(AnalysisScope.APPLICATION);
    final String path = classPath.getPath();
    if (path.endsWith(".jar") || path.endsWith(".apk") || path.endsWith(".dex")) {
      scope.addToScope(loader, DexFileModule.make(new File(classPath)));
    } else {
      throw new IOException("could not determine type of classpath from file extension: " + path);
    }

    return scope;
  }
}
